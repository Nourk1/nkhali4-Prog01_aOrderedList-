import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 * <Main class that controls writing and reading files>
 * 
 * CSC 1351 Programming Project No <1 Part A>
 * Section <002>
 * 
 * @author <Nour Khalifa>
 * @since <03/17/2024>
 *
 */
public class Prog01_aOrderedList {

	/**
	 * <Gets the Input File and returns a Scanner object to read data in input file>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public static Scanner getInputFile(String userPrompt) throws FileNotFoundException{
		Scanner scanner = new Scanner(System.in);
		File inputFile;
		String fileName;
		do{
			// Prompt the user to enter the input filename
			System.out.print(userPrompt);
			fileName = scanner.nextLine();
			inputFile = new File(fileName);
			// Check if the input file exists
			if (!inputFile.exists()) {
				//file doesn't exist ask want to continue
				System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N> ");
				String response = scanner.nextLine();

				//user doesn't want to continue, throw FileNotFoundException
				if (!response.equalsIgnoreCase("Y")) {

					throw new FileNotFoundException("User cancelled program execution.");

				}
			} 
		}while(!inputFile.exists());
		// Return a Scanner object to read from the input file
		return new Scanner(inputFile); 
	}

	/**
	 * <Gets the OutputFile and returns a PrintWriter object to write data in output file>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {
		Scanner outScanner = new Scanner(System.in);
		File outputFile;
		String fileName;
		String answer;
		do {
			// Prompt user for output filename
			System.out.print(userPrompt);
			fileName = outScanner.next();
			outputFile = new File(fileName);
			// Check if the output file exists
			if (!outputFile.exists()) {
				//file doesn't exist ask want to continue
				System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N> ");
				while(outScanner.hasNext()) {
					answer = outScanner.next();
					switch (answer) {
					case "Y":
						GetOutputFile(userPrompt);
						break;
					case "N":
						outScanner.close();
						throw new FileNotFoundException("User cancelled program execution.");
					default:
						System.out.println( "Please enter <Y/N> ");
					}

				} 
			}

		}while(!outputFile.exists());
		outScanner.close();
		return new PrintWriter(outputFile);
	}

	/**
	 * <Main method of program>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public static void main(String[] args) throws FileNotFoundException{
		// Get input file and create an ordered list
		Scanner inputScanner = getInputFile("Enter input filename: ");
		aOrderedList orderedList = new aOrderedList();
		// Read data from input file and process
		while (inputScanner.hasNextLine()) {
			String [] carInfo = inputScanner.nextLine().split(",");


			if (carInfo.length==4 && carInfo[0].equals("A")) {
				// Add a new car to the ordered list
				String make = carInfo[1];
				int year = Integer.parseInt(carInfo[2]);
				int price = Integer.parseInt(carInfo[3]);
				Car newCar = new Car(make, year, price);
				orderedList.add(newCar);
			}
			else if (carInfo.length==3 && carInfo[0].equals("D")) {
				// Remove a car from the ordered list
				String make = carInfo[1];
				int year = Integer.parseInt(carInfo[2]);
				orderedList.reset();
				while (orderedList.hasNext()) {
					Car car =(Car) orderedList.next();
					if(car.getMake().equals(make) && car.getYear() == year)
					{

						orderedList.remove();
						break;
					}
				}
			}
		}

		inputScanner.close();






		// Gets output file and write car details in 
		PrintWriter writeOutput = GetOutputFile("Enter output filename: ");
		writeOutput.printf("%s\t%10s\n", "Number of cars: ", orderedList.size());
		writeOutput.println();
		orderedList.reset();


		while(orderedList.hasNext()) {
			Comparable<?> carObj = orderedList.next();
			try {
				Car car = (Car) carObj;
				writeOutput.printf(" Make:\t%10s\n " ,car.getMake());
				writeOutput.printf("Year:\t%10d\n " ,car.getYear());
				String formatPrice = String.format("$%,d",car.getPrice());
				writeOutput.printf("Price:\t%10s\n",formatPrice);
				writeOutput.println();
			}catch(Exception e) {
				System.err.println();
			}

		}
		writeOutput.close();
	}
}

