import java.util.Arrays;

/**
 * <Manages and changes a sorted list of Car objects while keeping the list in a sorted order>
 * 
 * CSC 1351 Programming Project No <1 Part A>
 * Section <002>
 * 
 * @author <Nour Khalifa>
 * @since <03/17/2024>
 *
 */
class aOrderedList  {
	private final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
	private  Comparable<Car>[] oList; //the ordered list
	private int listSize; //the size of the ordered
	private int numObjects; //the number of objects in the ordered list
	private int curr; //index of current element accessed via iterator methods


	/**
	 * <Constructor of aOrderedList class that sets variables and initiates array>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public aOrderedList() {
		listSize = SIZEINCREMENTS;
		oList = new Car[SIZEINCREMENTS];
		numObjects = 0;
	}
	/**
	 * <Adds the newObject object to the sorted array in the correct position to maintain sorted order>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public void add(Comparable<Car> newObject) {
		int index = 0; // stores index
		// checks for resizing
		if (numObjects == listSize) {
			listSize += SIZEINCREMENTS;
			oList = Arrays.copyOf(oList, listSize);

		}
		//finds correct position to insert newObject
		while (index < numObjects && newObject.compareTo((Car)oList[index]) > 0) {
			index++;
		}
		//shifts elements to make space for newObject
		for(int i =numObjects-1; i >= index;i--) {
			oList[i+1]=oList[i];
		}
		//inserts newObject in correct position
		oList[index]= newObject;
		numObjects++;
	}
	/**
	 * <Returns the toString values of the list objects, separated by commas, and delimited by brackets>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	@Override
	public String toString() {
		// make string format of the list
		String toString = "[";
		for (int i = 0; i < numObjects; i++) {
			toString += oList[i].toString();
			if (i < numObjects - 1) {
				toString += ", ";
			}
		}
		toString += "]";
		return toString;
	}

	/**
	 * <Returns the number of elements in this list>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public int size(){
		return numObjects;
	}
	/**
	 * <Returns true if the array is empty and false otherwise>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public boolean isEmpty(){
		return numObjects == 0;
	}
	/**
	 * <Removes the element at the specified position in this list>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public void remove(int index) {
		// Check if index is within valid range
		if(index < 0 || index >= numObjects) {
			return;
		}
		else{
			// Shift elements to remove the element at the specified index
			for(int i = index; i < numObjects - 1; i++) {
				oList[i] = oList[i + 1];
			}
			// Decrement the number of objects 
			numObjects--;
		}
	}
	/**
	 * <Returns the element at the specified position in this list>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public Comparable<Car> get(int index) {
		// Check if index is within valid range
		if(index < 0 || index >= numObjects){
			return null;
		}
		else{
			// Return the element at the specified index
			return  oList[index];
		}
	}
	/**
	 * <Resets iterator parameters so that the “next” element is the first element  in the array, if any >
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public void reset(){
		curr = 0;
	}
	/**
	 * <Returns the next element in the iteration and increments the iterator parameters.>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public Comparable<Car> next() {
		Comparable<Car> car = oList[curr];
		curr++;
		return car;
	}
	/**
	 * <Returns true if the iteration has more elements to iterate through>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public boolean hasNext() {
		if (curr < numObjects) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * <Removes the last element returned by the next() method>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public void remove() {
		//decrements the current index
		remove(curr - 1);
	}


}


