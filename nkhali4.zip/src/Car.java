/**
 * <Class Car contains car info and implements Comparable interface with generic type car >
 * 
 * CSC 1351 Programming Project No <1 Part A>
 * Section <002>
 * 
 * @author <Nour Khalifa>
 * @since <03/17/2024>
 *
 */

class Car implements Comparable<Car> {
	private String make;
	private int year;
	private int price;
	/**
	 * <constructor that sets the values of make, year, and price>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public Car(String make, int year, int price) {
		this.make = make;
		this.year = year;
		this.price = price;
	}
	/**
	 * <returns the value of make>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public String getMake() {
		return make;
	}
	/**
	 * <returns the value of year>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public int getYear() {
		return year;
	}
	/**
	 * <returns the value of price>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * <compares two different cars based on make and year>
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	@Override
	public int compareTo(Car other) {
		// Compare makes of the cars
		if (this.make.compareTo(other.make)==0) {
			// If makes are the same, compare years of the cars
			return Integer.compare(year,other.year);
		}else {
			// If makes are different, compare based on make
			return this.make.compareTo(other.make);
		}

	}
	/**
	 * <returns the a string in certain format >
	 * 
	 * CSC 1351 Programming Project No <1 Part A>
	 * Section <002>
	 * 
	 * @author <Nour Khalifa>
	 * @since <03/17/2024>
	 *
	 */
	@Override
	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price;
	}
}
